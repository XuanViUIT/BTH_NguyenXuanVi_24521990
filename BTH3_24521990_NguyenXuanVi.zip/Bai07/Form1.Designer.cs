﻿namespace Bai07
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            pnlGhe = new Panel();
            btn15 = new Button();
            btn14 = new Button();
            btn1 = new Button();
            btn13 = new Button();
            btn12 = new Button();
            btn11 = new Button();
            btn10 = new Button();
            btn9 = new Button();
            btn8 = new Button();
            btn7 = new Button();
            btn6 = new Button();
            btn5 = new Button();
            btn4 = new Button();
            btn3 = new Button();
            btn2 = new Button();
            lblThanhTien = new Label();
            btnChon = new Button();
            btnHuy = new Button();
            btnKetThuc = new Button();
            lblTong = new Label();
            pnlGhe.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Dock = DockStyle.Top;
            label1.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.DarkOrange;
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(800, 69);
            label1.TabIndex = 0;
            label1.Text = "MÀN ẢNH";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlGhe
            // 
            pnlGhe.Controls.Add(btn15);
            pnlGhe.Controls.Add(btn14);
            pnlGhe.Controls.Add(btn1);
            pnlGhe.Controls.Add(btn13);
            pnlGhe.Controls.Add(btn12);
            pnlGhe.Controls.Add(btn11);
            pnlGhe.Controls.Add(btn10);
            pnlGhe.Controls.Add(btn9);
            pnlGhe.Controls.Add(btn8);
            pnlGhe.Controls.Add(btn7);
            pnlGhe.Controls.Add(btn6);
            pnlGhe.Controls.Add(btn5);
            pnlGhe.Controls.Add(btn4);
            pnlGhe.Controls.Add(btn3);
            pnlGhe.Controls.Add(btn2);
            pnlGhe.Location = new Point(217, 72);
            pnlGhe.Name = "pnlGhe";
            pnlGhe.Size = new Size(392, 218);
            pnlGhe.TabIndex = 1;
            // 
            // btn15
            // 
            btn15.BackColor = Color.White;
            btn15.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn15.Location = new Point(302, 155);
            btn15.Name = "btn15";
            btn15.Size = new Size(60, 60);
            btn15.TabIndex = 14;
            btn15.Text = "15";
            btn15.UseVisualStyleBackColor = false;
            // 
            // btn14
            // 
            btn14.BackColor = Color.White;
            btn14.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn14.Location = new Point(236, 155);
            btn14.Name = "btn14";
            btn14.Size = new Size(60, 60);
            btn14.TabIndex = 13;
            btn14.Text = "14";
            btn14.UseVisualStyleBackColor = false;
            // 
            // btn1
            // 
            btn1.BackColor = Color.White;
            btn1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn1.Location = new Point(38, 3);
            btn1.Name = "btn1";
            btn1.Size = new Size(60, 60);
            btn1.TabIndex = 0;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = false;
            // 
            // btn13
            // 
            btn13.BackColor = Color.White;
            btn13.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn13.Location = new Point(170, 155);
            btn13.Name = "btn13";
            btn13.Size = new Size(60, 60);
            btn13.TabIndex = 12;
            btn13.Text = "13";
            btn13.UseVisualStyleBackColor = false;
            // 
            // btn12
            // 
            btn12.BackColor = Color.White;
            btn12.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn12.Location = new Point(104, 155);
            btn12.Name = "btn12";
            btn12.Size = new Size(60, 60);
            btn12.TabIndex = 11;
            btn12.Text = "12";
            btn12.UseVisualStyleBackColor = false;
            // 
            // btn11
            // 
            btn11.BackColor = Color.White;
            btn11.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn11.Location = new Point(38, 155);
            btn11.Name = "btn11";
            btn11.Size = new Size(60, 60);
            btn11.TabIndex = 10;
            btn11.Text = "11";
            btn11.UseVisualStyleBackColor = false;
            // 
            // btn10
            // 
            btn10.BackColor = Color.White;
            btn10.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn10.Location = new Point(302, 79);
            btn10.Name = "btn10";
            btn10.Size = new Size(60, 60);
            btn10.TabIndex = 9;
            btn10.Text = "10";
            btn10.UseVisualStyleBackColor = false;
            // 
            // btn9
            // 
            btn9.BackColor = Color.White;
            btn9.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn9.Location = new Point(236, 79);
            btn9.Name = "btn9";
            btn9.Size = new Size(60, 60);
            btn9.TabIndex = 8;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = false;
            // 
            // btn8
            // 
            btn8.BackColor = Color.White;
            btn8.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn8.Location = new Point(170, 79);
            btn8.Name = "btn8";
            btn8.Size = new Size(60, 60);
            btn8.TabIndex = 7;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = false;
            // 
            // btn7
            // 
            btn7.BackColor = Color.White;
            btn7.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn7.Location = new Point(104, 79);
            btn7.Name = "btn7";
            btn7.Size = new Size(60, 60);
            btn7.TabIndex = 6;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = false;
            // 
            // btn6
            // 
            btn6.BackColor = Color.White;
            btn6.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn6.Location = new Point(38, 79);
            btn6.Name = "btn6";
            btn6.Size = new Size(60, 60);
            btn6.TabIndex = 5;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = false;
            // 
            // btn5
            // 
            btn5.BackColor = Color.White;
            btn5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn5.Location = new Point(302, 3);
            btn5.Name = "btn5";
            btn5.Size = new Size(60, 60);
            btn5.TabIndex = 4;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = false;
            // 
            // btn4
            // 
            btn4.BackColor = Color.White;
            btn4.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn4.Location = new Point(236, 3);
            btn4.Name = "btn4";
            btn4.Size = new Size(60, 60);
            btn4.TabIndex = 3;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = false;
            // 
            // btn3
            // 
            btn3.BackColor = Color.White;
            btn3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn3.Location = new Point(170, 3);
            btn3.Name = "btn3";
            btn3.Size = new Size(60, 60);
            btn3.TabIndex = 2;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = false;
            // 
            // btn2
            // 
            btn2.BackColor = Color.White;
            btn2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btn2.Location = new Point(104, 3);
            btn2.Name = "btn2";
            btn2.Size = new Size(60, 60);
            btn2.TabIndex = 1;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = false;
            // 
            // lblThanhTien
            // 
            lblThanhTien.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblThanhTien.Location = new Point(217, 329);
            lblThanhTien.Name = "lblThanhTien";
            lblThanhTien.Size = new Size(116, 40);
            lblThanhTien.TabIndex = 2;
            lblThanhTien.Text = "Thành Tiền:";
            // 
            // btnChon
            // 
            btnChon.Location = new Point(217, 385);
            btnChon.Name = "btnChon";
            btnChon.Size = new Size(94, 36);
            btnChon.TabIndex = 4;
            btnChon.Text = "Chọn";
            btnChon.UseVisualStyleBackColor = true;
            btnChon.Click += btnChon_Click;
            // 
            // btnHuy
            // 
            btnHuy.Location = new Point(335, 385);
            btnHuy.Name = "btnHuy";
            btnHuy.Size = new Size(94, 36);
            btnHuy.TabIndex = 5;
            btnHuy.Text = "Hủy bỏ";
            btnHuy.UseVisualStyleBackColor = true;
            btnHuy.Click += btnHuy_Click;
            // 
            // btnKetThuc
            // 
            btnKetThuc.Location = new Point(453, 385);
            btnKetThuc.Name = "btnKetThuc";
            btnKetThuc.Size = new Size(94, 36);
            btnKetThuc.TabIndex = 6;
            btnKetThuc.Text = "Kết Thúc";
            btnKetThuc.UseVisualStyleBackColor = true;
            btnKetThuc.Click += btnKetThuc_Click;
            // 
            // lblTong
            // 
            lblTong.BackColor = Color.White;
            lblTong.BorderStyle = BorderStyle.FixedSingle;
            lblTong.Location = new Point(335, 324);
            lblTong.Name = "lblTong";
            lblTong.Size = new Size(212, 31);
            lblTong.TabIndex = 7;
            lblTong.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(800, 450);
            Controls.Add(lblTong);
            Controls.Add(btnKetThuc);
            Controls.Add(btnHuy);
            Controls.Add(btnChon);
            Controls.Add(lblThanhTien);
            Controls.Add(pnlGhe);
            Controls.Add(label1);
            Name = "Form1";
            Text = "BÁN VÉ RẠP CHIẾU BÓNG";
            pnlGhe.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Panel pnlGhe;
        private Button btn10;
        private Button btn9;
        private Button btn8;
        private Button btn7;
        private Button btn6;
        private Button btn5;
        private Button btn4;
        private Button btn3;
        private Button btn2;
        private Button btn1;
        private Button btn15;
        private Button btn14;
        private Button btn13;
        private Button btn12;
        private Button btn11;
        private Label lblThanhTien;
        private Button btnChon;
        private Button btnHuy;
        private Button btnKetThuc;
        private Label lblTong;
    }
}
