using System.Drawing.Text;

namespace Bai06
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadFonts();
            lstFonts.DrawItem += lstFonts_DrawItem;
        }
        private void LoadFonts()
        {
            InstalledFontCollection fonts = new InstalledFontCollection();
            foreach(var font in fonts.Families)
            {
                lstFonts.Items.Add(font.Name);
            }
        }
        private void lstFonts_DrawItem(object? sender, DrawItemEventArgs e) 
        {
                e.DrawBackground();
                if(e.Index >= 0)
                {
                    string fontName = lstFonts.Items[e.Index].ToString() ?? string.Empty;
                    Font fontToDraw;
                    try
                    {
                        fontToDraw = new Font(fontName, 12, FontStyle.Regular);
                    }
                    catch
                    {
                        fontToDraw = new Font(fontName, 12, FontStyle.Bold);
                    }
                e.Graphics.DrawString(fontName, fontToDraw, Brushes.Black, e.Bounds);
                }
            e.DrawFocusRectangle();
        }
    }
}
