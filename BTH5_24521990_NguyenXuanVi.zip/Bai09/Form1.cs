using System;
using System.Drawing;
using System.Windows.Forms;

namespace Bai09
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cmbShape.SelectedIndexChanged += (s, e) => Invalidate();
            cmbShape.SelectedIndex = 0;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            int rectW = 300;
            int rectH = 200;
            int squareSide = 200;
            
            int xRect = (this.ClientSize.Width - rectW) / 2;
            int yRect = (this.ClientSize.Height - rectH) / 2;

            int xSquare = (this.ClientSize.Width - squareSide) / 2;
            int ySquare = (this.ClientSize.Height - squareSide) / 2;

            string shape = cmbShape.Text;
            Rectangle rect = new Rectangle(xRect, yRect, rectW, rectH); 
            Rectangle square = new Rectangle(xSquare, ySquare, squareSide, squareSide); 

            Pen pen = new Pen(Color.Black, 3);
            Brush brush = Brushes.Red;

            switch (shape)
            {
                case "Circle": g.DrawEllipse(pen, square); 
                    break;
                case "Square": g.DrawRectangle(pen, square); 
                    break;
                case "Ellipse": g.DrawEllipse(pen, rect); 
                    break;
                case "Pie": g.DrawPie(pen, rect, 0, 135); 
                    break;
                case "Filled Circle": g.FillEllipse(brush, square); 
                    break;
                case "Filled Square": g.FillRectangle(brush, square); 
                    break;
                case "Filled Ellipse": g.FillEllipse(brush, rect); 
                    break;
                case "Filled Pie": g.FillPie(brush, rect, 0, 135); 
                    break;
            }
        }
    }
}