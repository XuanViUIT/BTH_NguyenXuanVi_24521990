﻿namespace Bai09
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbShape = new ComboBox();
            SuspendLayout();
            // 
            // cmbShape
            // 
            cmbShape.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            cmbShape.FormattingEnabled = true;
            cmbShape.Items.AddRange(new object[] { "Circle", "Square", "Ellipse", "Pie", "Filled Circle", "Filled Square", "Filled Ellipse", "Filled Pie" });
            cmbShape.Location = new Point(12, 12);
            cmbShape.Name = "cmbShape";
            cmbShape.Size = new Size(151, 28);
            cmbShape.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(382, 353);
            Controls.Add(cmbShape);
            DoubleBuffered = true;
            Name = "Form1";
            Text = "ComboBoxTest";
            ResumeLayout(false);
        }

        #endregion

        private ComboBox cmbShape;
    }
}
