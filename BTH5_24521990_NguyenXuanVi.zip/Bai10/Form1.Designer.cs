﻿namespace Bai10
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbDashCap = new ComboBox();
            cmbLineJoin = new ComboBox();
            cmbDashStyle = new ComboBox();
            cmbStartCap = new ComboBox();
            cmbEndCap = new ComboBox();
            numWidth = new NumericUpDown();
            pnlDraw = new FlowLayoutPanel();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)numWidth).BeginInit();
            SuspendLayout();
            // 
            // cmbDashCap
            // 
            cmbDashCap.FormattingEnabled = true;
            cmbDashCap.Location = new Point(145, 212);
            cmbDashCap.Name = "cmbDashCap";
            cmbDashCap.Size = new Size(151, 28);
            cmbDashCap.TabIndex = 0;
            // 
            // cmbLineJoin
            // 
            cmbLineJoin.FormattingEnabled = true;
            cmbLineJoin.Location = new Point(145, 149);
            cmbLineJoin.Name = "cmbLineJoin";
            cmbLineJoin.Size = new Size(151, 28);
            cmbLineJoin.TabIndex = 2;
            // 
            // cmbDashStyle
            // 
            cmbDashStyle.FormattingEnabled = true;
            cmbDashStyle.Location = new Point(145, 24);
            cmbDashStyle.Name = "cmbDashStyle";
            cmbDashStyle.Size = new Size(151, 28);
            cmbDashStyle.TabIndex = 3;
            // 
            // cmbStartCap
            // 
            cmbStartCap.FormattingEnabled = true;
            cmbStartCap.Location = new Point(145, 275);
            cmbStartCap.Name = "cmbStartCap";
            cmbStartCap.Size = new Size(151, 28);
            cmbStartCap.TabIndex = 4;
            // 
            // cmbEndCap
            // 
            cmbEndCap.FormattingEnabled = true;
            cmbEndCap.Location = new Point(146, 338);
            cmbEndCap.Name = "cmbEndCap";
            cmbEndCap.Size = new Size(151, 28);
            cmbEndCap.TabIndex = 5;
            // 
            // numWidth
            // 
            numWidth.Location = new Point(146, 87);
            numWidth.Name = "numWidth";
            numWidth.Size = new Size(150, 27);
            numWidth.TabIndex = 6;
            // 
            // pnlDraw
            // 
            pnlDraw.BackColor = Color.White;
            pnlDraw.Location = new Point(349, 0);
            pnlDraw.Name = "pnlDraw";
            pnlDraw.Size = new Size(453, 451);
            pnlDraw.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(57, 27);
            label1.Name = "label1";
            label1.Size = new Size(78, 20);
            label1.TabIndex = 8;
            label1.Text = "Dash Style";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(57, 91);
            label2.Name = "label2";
            label2.Size = new Size(49, 20);
            label2.TabIndex = 9;
            label2.Text = "Width";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(57, 155);
            label3.Name = "label3";
            label3.Size = new Size(66, 20);
            label3.TabIndex = 10;
            label3.Text = "Line Join";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(57, 219);
            label4.Name = "label4";
            label4.Size = new Size(72, 20);
            label4.TabIndex = 11;
            label4.Text = "Dash Cap";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(57, 283);
            label5.Name = "label5";
            label5.Size = new Size(70, 20);
            label5.TabIndex = 12;
            label5.Text = "Start Cap";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(57, 347);
            label6.Name = "label6";
            label6.Size = new Size(64, 20);
            label6.TabIndex = 13;
            label6.Text = "End Cap";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.MenuBar;
            ClientSize = new Size(800, 450);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pnlDraw);
            Controls.Add(numWidth);
            Controls.Add(cmbEndCap);
            Controls.Add(cmbStartCap);
            Controls.Add(cmbDashStyle);
            Controls.Add(cmbLineJoin);
            Controls.Add(cmbDashCap);
            Name = "Form1";
            Text = "Pen Demo";
            ((System.ComponentModel.ISupportInitialize)numWidth).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbDashCap;
        private ComboBox cmbLineJoin;
        private ComboBox cmbDashStyle;
        private ComboBox cmbStartCap;
        private ComboBox cmbEndCap;
        private NumericUpDown numWidth;
        private FlowLayoutPanel pnlDraw;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
    }
}
