using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Bai10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            cmbDashStyle.DataSource = Enum.GetValues(typeof(DashStyle));
            cmbLineJoin.DataSource = Enum.GetValues(typeof(LineJoin));
            cmbDashCap.DataSource = Enum.GetValues(typeof(DashCap));
            cmbStartCap.DataSource = Enum.GetValues(typeof(LineCap));
            cmbEndCap.DataSource = Enum.GetValues(typeof(LineCap));

            cmbDashStyle.SelectedItem = DashStyle.DashDot;
            cmbLineJoin.SelectedItem = LineJoin.Round;
            cmbDashCap.SelectedItem = DashCap.Triangle;
            cmbStartCap.SelectedItem = LineCap.RoundAnchor;
            cmbEndCap.SelectedItem = LineCap.ArrowAnchor;
            numWidth.Value = 15;

            cmbDashStyle.SelectedIndexChanged += Redraw;
            cmbLineJoin.SelectedIndexChanged += Redraw;
            cmbDashCap.SelectedIndexChanged += Redraw;
            cmbStartCap.SelectedIndexChanged += Redraw;
            cmbEndCap.SelectedIndexChanged += Redraw;
            numWidth.ValueChanged += Redraw;

            pnlDraw.Paint += PnlDraw_Paint;
        }

        private void Redraw(object? sender, EventArgs e)
        {
            pnlDraw.Invalidate();
        }

        private void PnlDraw_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            float width = (float)numWidth.Value;

            using (Pen p = new Pen(Color.Red, width))
            {

                if (cmbDashStyle.SelectedItem is DashStyle ds)
                    p.DashStyle = ds;

                if (cmbLineJoin.SelectedItem is LineJoin lj)
                    p.LineJoin = lj;

                if (cmbDashCap.SelectedItem is DashCap dc)
                    p.DashCap = dc;

                if (cmbStartCap.SelectedItem is LineCap sc)
                    p.StartCap = sc;

                if (cmbEndCap.SelectedItem is LineCap ec)
                    p.EndCap = ec;

                int w = pnlDraw.Width;
                int h = pnlDraw.Height;

                Point p1 = new Point(20, 20);
                Point p2 = new Point(w / 2, h - 50);
                Point p3 = new Point(w - 20, 20);

                Point[] points = { p1, p2, p3 };

                g.DrawLines(p, points);
            }
        }
    }
}