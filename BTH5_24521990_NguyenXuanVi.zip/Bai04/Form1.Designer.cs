﻿namespace Bai04
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            cmbFont = new ComboBox();
            cmbSize = new ComboBox();
            chkBold = new CheckBox();
            chkItalic = new CheckBox();
            chkUnderline = new CheckBox();
            grpAllign = new GroupBox();
            radRight = new RadioButton();
            radCenter = new RadioButton();
            radLeft = new RadioButton();
            lblColor = new Label();
            txtText = new TextBox();
            grpAllign.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(26, 61);
            label1.Name = "label1";
            label1.Size = new Size(48, 25);
            label1.TabIndex = 0;
            label1.Text = "Font";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(286, 62);
            label2.Name = "label2";
            label2.Size = new Size(43, 25);
            label2.TabIndex = 1;
            label2.Text = "Size";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(274, 112);
            label3.Name = "label3";
            label3.Size = new Size(55, 25);
            label3.TabIndex = 2;
            label3.Text = "Color";
            // 
            // cmbFont
            // 
            cmbFont.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbFont.FormattingEnabled = true;
            cmbFont.Location = new Point(80, 62);
            cmbFont.Name = "cmbFont";
            cmbFont.Size = new Size(151, 28);
            cmbFont.TabIndex = 3;
            // 
            // cmbSize
            // 
            cmbSize.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSize.FormattingEnabled = true;
            cmbSize.Location = new Point(335, 61);
            cmbSize.Name = "cmbSize";
            cmbSize.Size = new Size(89, 28);
            cmbSize.TabIndex = 4;
            // 
            // chkBold
            // 
            chkBold.AutoSize = true;
            chkBold.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            chkBold.Location = new Point(28, 112);
            chkBold.Name = "chkBold";
            chkBold.Size = new Size(46, 29);
            chkBold.TabIndex = 5;
            chkBold.Text = "B";
            chkBold.UseVisualStyleBackColor = true;
            // 
            // chkItalic
            // 
            chkItalic.AutoSize = true;
            chkItalic.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            chkItalic.Location = new Point(96, 112);
            chkItalic.Name = "chkItalic";
            chkItalic.Size = new Size(40, 29);
            chkItalic.TabIndex = 6;
            chkItalic.Text = "I";
            chkItalic.UseVisualStyleBackColor = true;
            // 
            // chkUnderline
            // 
            chkUnderline.AutoSize = true;
            chkUnderline.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            chkUnderline.Location = new Point(158, 112);
            chkUnderline.Name = "chkUnderline";
            chkUnderline.Size = new Size(47, 29);
            chkUnderline.TabIndex = 7;
            chkUnderline.Text = "U";
            chkUnderline.UseVisualStyleBackColor = true;
            // 
            // grpAllign
            // 
            grpAllign.Controls.Add(radRight);
            grpAllign.Controls.Add(radCenter);
            grpAllign.Controls.Add(radLeft);
            grpAllign.Location = new Point(26, 171);
            grpAllign.Name = "grpAllign";
            grpAllign.Size = new Size(179, 147);
            grpAllign.TabIndex = 8;
            grpAllign.TabStop = false;
            grpAllign.Text = "Allign Text";
            // 
            // radRight
            // 
            radRight.AutoSize = true;
            radRight.Location = new Point(28, 105);
            radRight.Name = "radRight";
            radRight.Size = new Size(65, 24);
            radRight.TabIndex = 2;
            radRight.TabStop = true;
            radRight.Text = "Right";
            radRight.UseVisualStyleBackColor = true;
            // 
            // radCenter
            // 
            radCenter.AutoSize = true;
            radCenter.Location = new Point(28, 70);
            radCenter.Name = "radCenter";
            radCenter.Size = new Size(73, 24);
            radCenter.TabIndex = 1;
            radCenter.TabStop = true;
            radCenter.Text = "Center";
            radCenter.UseVisualStyleBackColor = true;
            // 
            // radLeft
            // 
            radLeft.AutoSize = true;
            radLeft.Location = new Point(28, 35);
            radLeft.Name = "radLeft";
            radLeft.Size = new Size(55, 24);
            radLeft.TabIndex = 0;
            radLeft.TabStop = true;
            radLeft.Text = "Left";
            radLeft.UseVisualStyleBackColor = true;
            // 
            // lblColor
            // 
            lblColor.BackColor = SystemColors.WindowText;
            lblColor.BorderStyle = BorderStyle.FixedSingle;
            lblColor.Location = new Point(335, 112);
            lblColor.Name = "lblColor";
            lblColor.Size = new Size(41, 27);
            lblColor.TabIndex = 10;
            lblColor.Click += lblColor_Click;
            // 
            // txtText
            // 
            txtText.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtText.Font = new Font("Segoe UI", 28.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtText.ForeColor = SystemColors.WindowText;
            txtText.Location = new Point(229, 206);
            txtText.Multiline = true;
            txtText.Name = "txtText";
            txtText.Size = new Size(270, 73);
            txtText.TabIndex = 11;
            txtText.Text = "Hello";
            txtText.TextAlign = HorizontalAlignment.Center;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(556, 388);
            Controls.Add(txtText);
            Controls.Add(lblColor);
            Controls.Add(grpAllign);
            Controls.Add(chkUnderline);
            Controls.Add(chkItalic);
            Controls.Add(chkBold);
            Controls.Add(cmbSize);
            Controls.Add(cmbFont);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            grpAllign.ResumeLayout(false);
            grpAllign.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox cmbFont;
        private ComboBox cmbSize;
        private CheckBox chkBold;
        private CheckBox chkItalic;
        private CheckBox chkUnderline;
        private GroupBox grpAllign;
        private RadioButton radRight;
        private RadioButton radCenter;
        private RadioButton radLeft;
        private Label lblColor;
        private TextBox txtText;
    }
}
