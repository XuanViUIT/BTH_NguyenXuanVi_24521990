using System.Drawing.Text;

namespace Bai04
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadFontAndSize();
            cmbFont.SelectedIndexChanged += new EventHandler(UpdateFont);
            cmbSize.SelectedIndexChanged += new EventHandler(UpdateFont);
            chkBold.CheckedChanged += new EventHandler(UpdateFont);
            chkItalic.CheckedChanged += new EventHandler(UpdateFont);
            chkUnderline.CheckedChanged += new EventHandler(UpdateFont);
            radLeft.CheckedChanged += new EventHandler(UpdateAlign);
            radCenter.CheckedChanged += new EventHandler(UpdateAlign);
            radRight.CheckedChanged += new EventHandler(UpdateAlign);
            this.ActiveControl = null;
        }
        private void LoadFontAndSize()
        {
            InstalledFontCollection fonts = new InstalledFontCollection();
            foreach (var font in fonts.Families)
            {
                cmbFont.Items.Add(font.Name);
            }
            cmbFont.Text = "Arial";

            int[] size = { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72 };
            foreach (var item in size)
            {
                cmbSize.Items.Add(item);
            }
            cmbSize.Text = "28";
        }
        private void UpdateFont(object? sender, EventArgs e)
        {
            string FontName = cmbFont.Text;
            float FontSize = float.Parse(cmbSize.Text);
            FontStyle style = FontStyle.Regular;
            if (chkBold.Checked)
                style |= FontStyle.Bold;
            if (chkItalic.Checked)
                style |= FontStyle.Italic;
            if (chkUnderline.Checked)
                style |= FontStyle.Underline;
            txtText.Font = new Font(FontName, FontSize, style);
        }
        private void UpdateAlign(object? sender, EventArgs e)
        {
            if (radLeft.Checked)
                txtText.TextAlign = HorizontalAlignment.Left;
            if (radCenter.Checked)
                txtText.TextAlign = HorizontalAlignment.Center;
            if (radRight.Checked)
                txtText.TextAlign = HorizontalAlignment.Right;
        }

        private void lblColor_Click(object? sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if(colorDialog.ShowDialog() == DialogResult.OK)
            {
                txtText.ForeColor = colorDialog.Color;
                lblColor.BackColor = colorDialog.Color;
            }
        }
    }
}
