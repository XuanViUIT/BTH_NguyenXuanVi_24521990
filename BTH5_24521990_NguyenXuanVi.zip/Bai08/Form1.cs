using System.Configuration;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
namespace Bai08
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Tick += (s,e) => Invalidate();
        }

        private void Timer1_Tick(object? sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            int w = ClientSize.Width;
            int h = ClientSize.Height;
            int cw = w / 2, cy = h / 2;
            int radius = Math.Min(w, h) / 2 - 20;
            for (int i = 0; i < 60; i++)
            {
                double angle = i * 6 * Math.PI / 180;
                int pointSize = (i % 5 == 0) ? 8 : 4;
                int x = (int)(cw + radius * Math.Sin(angle));
                int y = (int)(cy - radius * Math.Cos(angle));
                g.FillEllipse(Brushes.White, x - pointSize / 2, y - pointSize / 2, pointSize, pointSize);
            }

            DateTime now = DateTime.Now;
            float hAngle = (now.Hour % 12 + now.Minute / 60f) * 30;
            float mAngle = (now.Minute + now.Second / 60f) * 6;
            float sAngle = now.Second * 6;
            DrawHand(g, cw, cy, hAngle, radius * 0.5f, Pens.White, 6);
            DrawHand(g, cw, cy, mAngle, radius * 0.7f, Pens.White, 4);
            DrawHand(g, cw, cy, sAngle, radius * 0.9f, Pens.Red, 2);
        }
        private void DrawHand(Graphics g, int cx, int cy, float angle, float length, Pen pen, int width)
        {
            GraphicsState state = g.Save();
            g.TranslateTransform(cx, cy);
            g.RotateTransform(angle - 90);
            g.DrawLine(new Pen(pen.Color, width), 0, 0, length, 0);
            g.Restore(state);
        }
    }
}
