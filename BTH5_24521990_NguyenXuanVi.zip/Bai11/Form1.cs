﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Bai11
{
    public partial class Form1 : Form
    {
        Bitmap mainBitmap;
        Point startPoint;
        bool isDrawing = false;
        Color currentColor = Color.Blue;

        public Form1()
        {
            InitializeComponent();

            mainBitmap = new Bitmap(picDraw.Width, picDraw.Height);
            using (Graphics g = Graphics.FromImage(mainBitmap))
            {
                g.Clear(Color.White);
            }
            picDraw.Image = mainBitmap;

            radLine.Checked = true;
            radSolid.Checked = true;

            picDraw.MouseDown += PicDraw_MouseDown;
            picDraw.MouseMove += PicDraw_MouseMove;
            picDraw.MouseUp += PicDraw_MouseUp;
            picDraw.Paint += PicDraw_Paint;
            btnColor.Click += BtnColor_Click;
        }

        private void BtnColor_Click(object? sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK) currentColor = cd.Color;
        }

        private void PicDraw_MouseDown(object? sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDrawing = true;
                startPoint = e.Location;
            }
        }

        private void PicDraw_MouseMove(object? sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
                picDraw.Invalidate();
            }
        }

        private void PicDraw_MouseUp(object? sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
                isDrawing = false;

                using (Graphics g = Graphics.FromImage(mainBitmap))
                {
                    DrawShape(g, e.Location);
                }

                picDraw.Invalidate();
            }
        }

        private void PicDraw_Paint(object? sender, PaintEventArgs e)
        {
            if (isDrawing)
            {
                Point currentPoint = picDraw.PointToClient(Cursor.Position);
                DrawShape(e.Graphics, currentPoint);
            }
        }

        private void DrawShape(Graphics g, Point endPoint)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int x = Math.Min(startPoint.X, endPoint.X);
            int y = Math.Min(startPoint.Y, endPoint.Y);
            int w = Math.Abs(startPoint.X - endPoint.X);
            int h = Math.Abs(startPoint.Y - endPoint.Y);

            if (w == 0) w = 1;
            if (h == 0) h = 1;

            Rectangle rect = new Rectangle(x, y, w, h);

            float width = 1;
            if (float.TryParse(txtWidth.Text, out float wVal)) width = wVal;

            using (Pen pen = new Pen(currentColor, width))
            {
                Brush brush;

                if (radHatch.Checked)
                {
                    brush = new HatchBrush(HatchStyle.Horizontal, Color.Blue, Color.Green);
                }
                else if (radLinear.Checked)
                {
                    brush = new LinearGradientBrush(rect, Color.Red, Color.Green, LinearGradientMode.Vertical);
                }
                else if (radTexture.Checked)
                {
                    brush = new HatchBrush(HatchStyle.LargeCheckerBoard, Color.DarkRed, Color.White);
                }
                else
                {
                    brush = new SolidBrush(Color.Green);
                }

                if (radLine.Checked)
                {
                    g.DrawLine(pen, startPoint, endPoint);
                }
                else if (radRect.Checked)
                {
                    g.FillRectangle(brush, rect);
                    g.DrawRectangle(pen, rect);
                }
                else if (radEllipse.Checked)
                {
                    g.FillEllipse(brush, rect);
                    g.DrawEllipse(pen, rect);
                }

                brush.Dispose();
            }
        }
    }
}