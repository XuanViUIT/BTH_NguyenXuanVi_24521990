﻿namespace Bai11
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpShapes = new GroupBox();
            radEllipse = new RadioButton();
            radRect = new RadioButton();
            radLine = new RadioButton();
            grpPen = new GroupBox();
            txtWidth = new TextBox();
            label1 = new Label();
            btnColor = new Button();
            grpBrushes = new GroupBox();
            radLinear = new RadioButton();
            radTexture = new RadioButton();
            radHatch = new RadioButton();
            radSolid = new RadioButton();
            picDraw = new PictureBox();
            grpShapes.SuspendLayout();
            grpPen.SuspendLayout();
            grpBrushes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picDraw).BeginInit();
            SuspendLayout();
            // 
            // grpShapes
            // 
            grpShapes.Controls.Add(radEllipse);
            grpShapes.Controls.Add(radRect);
            grpShapes.Controls.Add(radLine);
            grpShapes.Location = new Point(23, 12);
            grpShapes.Name = "grpShapes";
            grpShapes.Size = new Size(177, 126);
            grpShapes.TabIndex = 0;
            grpShapes.TabStop = false;
            grpShapes.Text = "Shapes";
            // 
            // radEllipse
            // 
            radEllipse.AutoSize = true;
            radEllipse.Location = new Point(6, 80);
            radEllipse.Name = "radEllipse";
            radEllipse.Size = new Size(73, 24);
            radEllipse.TabIndex = 2;
            radEllipse.TabStop = true;
            radEllipse.Text = "Ellipse";
            radEllipse.UseVisualStyleBackColor = true;
            // 
            // radRect
            // 
            radRect.AutoSize = true;
            radRect.Location = new Point(6, 50);
            radRect.Name = "radRect";
            radRect.Size = new Size(96, 24);
            radRect.TabIndex = 1;
            radRect.TabStop = true;
            radRect.Text = "Rectangle";
            radRect.UseVisualStyleBackColor = true;
            // 
            // radLine
            // 
            radLine.AutoSize = true;
            radLine.Location = new Point(6, 20);
            radLine.Name = "radLine";
            radLine.Size = new Size(57, 24);
            radLine.TabIndex = 0;
            radLine.TabStop = true;
            radLine.Text = "Line";
            radLine.UseVisualStyleBackColor = true;
            // 
            // grpPen
            // 
            grpPen.Controls.Add(txtWidth);
            grpPen.Controls.Add(label1);
            grpPen.Controls.Add(btnColor);
            grpPen.Location = new Point(23, 153);
            grpPen.Name = "grpPen";
            grpPen.Size = new Size(177, 121);
            grpPen.TabIndex = 1;
            grpPen.TabStop = false;
            grpPen.Text = "Pen";
            // 
            // txtWidth
            // 
            txtWidth.Location = new Point(64, 23);
            txtWidth.Name = "txtWidth";
            txtWidth.Size = new Size(79, 27);
            txtWidth.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 23);
            label1.Name = "label1";
            label1.Size = new Size(52, 20);
            label1.TabIndex = 1;
            label1.Text = "Width:";
            // 
            // btnColor
            // 
            btnColor.Location = new Point(32, 65);
            btnColor.Name = "btnColor";
            btnColor.Size = new Size(122, 29);
            btnColor.TabIndex = 0;
            btnColor.Text = "Color...";
            btnColor.UseVisualStyleBackColor = true;
            // 
            // grpBrushes
            // 
            grpBrushes.Controls.Add(radLinear);
            grpBrushes.Controls.Add(radTexture);
            grpBrushes.Controls.Add(radHatch);
            grpBrushes.Controls.Add(radSolid);
            grpBrushes.Location = new Point(23, 280);
            grpBrushes.Name = "grpBrushes";
            grpBrushes.Size = new Size(177, 196);
            grpBrushes.TabIndex = 2;
            grpBrushes.TabStop = false;
            grpBrushes.Text = "Brushes";
            // 
            // radLinear
            // 
            radLinear.AutoSize = true;
            radLinear.Location = new Point(6, 116);
            radLinear.Name = "radLinear";
            radLinear.Size = new Size(163, 24);
            radLinear.TabIndex = 3;
            radLinear.TabStop = true;
            radLinear.Text = "LinearGradientBrush";
            radLinear.UseVisualStyleBackColor = true;
            // 
            // radTexture
            // 
            radTexture.AutoSize = true;
            radTexture.Location = new Point(6, 86);
            radTexture.Name = "radTexture";
            radTexture.Size = new Size(114, 24);
            radTexture.TabIndex = 2;
            radTexture.TabStop = true;
            radTexture.Text = "TextureBrush";
            radTexture.UseVisualStyleBackColor = true;
            // 
            // radHatch
            // 
            radHatch.AutoSize = true;
            radHatch.Location = new Point(6, 56);
            radHatch.Name = "radHatch";
            radHatch.Size = new Size(105, 24);
            radHatch.TabIndex = 1;
            radHatch.TabStop = true;
            radHatch.Text = "HatchBrush";
            radHatch.UseVisualStyleBackColor = true;
            // 
            // radSolid
            // 
            radSolid.AutoSize = true;
            radSolid.Location = new Point(6, 26);
            radSolid.Name = "radSolid";
            radSolid.Size = new Size(100, 24);
            radSolid.TabIndex = 0;
            radSolid.TabStop = true;
            radSolid.Text = "SolidBrush";
            radSolid.UseVisualStyleBackColor = true;
            // 
            // picDraw
            // 
            picDraw.Dock = DockStyle.Right;
            picDraw.Location = new Point(218, 0);
            picDraw.Name = "picDraw";
            picDraw.Size = new Size(582, 488);
            picDraw.TabIndex = 3;
            picDraw.TabStop = false;
            picDraw.MouseDown += PicDraw_MouseDown;
            picDraw.MouseMove += PicDraw_MouseMove;
            picDraw.MouseUp += PicDraw_MouseUp;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 488);
            Controls.Add(picDraw);
            Controls.Add(grpBrushes);
            Controls.Add(grpPen);
            Controls.Add(grpShapes);
            Name = "Form1";
            Text = "Bai Thi";
            grpShapes.ResumeLayout(false);
            grpShapes.PerformLayout();
            grpPen.ResumeLayout(false);
            grpPen.PerformLayout();
            grpBrushes.ResumeLayout(false);
            grpBrushes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picDraw).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox grpShapes;
        private GroupBox grpPen;
        private GroupBox grpBrushes;
        private RadioButton radEllipse;
        private RadioButton radRect;
        private RadioButton radLine;
        private TextBox txtWidth;
        private Label label1;
        private Button btnColor;
        private RadioButton radLinear;
        private RadioButton radTexture;
        private RadioButton radHatch;
        private RadioButton radSolid;
        private PictureBox picDraw;
    }
}
