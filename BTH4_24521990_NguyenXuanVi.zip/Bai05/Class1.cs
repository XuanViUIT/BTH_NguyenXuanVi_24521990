﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bai05
{
    public class Student
    {
        public string MSSV { get; set; }
        public string TenSV { get; set; }
        public string Khoa { get; set; }
        public float diemTB { get; set; }
    }
}
