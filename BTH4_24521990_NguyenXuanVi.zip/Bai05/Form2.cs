﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bai05
{
    public partial class FrmThemSV : Form
    {
        public Student HocSinhMoi { get; private set; }
        public FrmThemSV()
        {
            InitializeComponent();
            cmbKhoa.SelectedIndex = 0;
        }

        private void btnThemMoi_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMSSV.Text) || string.IsNullOrEmpty(txtTenSV.Text) || string.IsNullOrEmpty(txtdiemTB.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return;
            }

            try
            {
                float diem = float.Parse(txtdiemTB.Text);

                if (diem < 0 || diem > 10)
                {
                    MessageBox.Show("Điểm trung bình phải nằm trong khoảng từ 0 đến 10!");
                    return;
                }

                HocSinhMoi = new Student()
                {
                    MSSV = txtMSSV.Text,
                    TenSV = txtTenSV.Text,
                    Khoa = cmbKhoa.Text,
                    diemTB = diem
                };

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Điểm trung bình phải là số hợp lệ! Lỗi: " + ex.Message);
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtMSSV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
