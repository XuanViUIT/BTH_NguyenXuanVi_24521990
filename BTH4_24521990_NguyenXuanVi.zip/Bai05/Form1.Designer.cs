﻿namespace Bai05
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            menuStrip1 = new MenuStrip();
            chứcNăngToolStripMenuItem = new ToolStripMenuItem();
            thêmMớiToolStripMenuItem = new ToolStripMenuItem();
            thoátToolStripMenuItem = new ToolStripMenuItem();
            lsvSinhVien = new ListView();
            columnSoTT = new ColumnHeader();
            columnMSSV = new ColumnHeader();
            columnTenSV = new ColumnHeader();
            columnKhoa = new ColumnHeader();
            columnDiemTB = new ColumnHeader();
            tsbThem = new ToolStripButton();
            tslblTimTheoTen = new ToolStripLabel();
            tsbTimKiem = new ToolStripTextBox();
            toolStrip1 = new ToolStrip();
            menuStrip1.SuspendLayout();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { chứcNăngToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(712, 28);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // chứcNăngToolStripMenuItem
            // 
            chứcNăngToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { thêmMớiToolStripMenuItem, thoátToolStripMenuItem });
            chứcNăngToolStripMenuItem.Name = "chứcNăngToolStripMenuItem";
            chứcNăngToolStripMenuItem.Size = new Size(96, 24);
            chứcNăngToolStripMenuItem.Text = "Chức Năng";
            // 
            // thêmMớiToolStripMenuItem
            // 
            thêmMớiToolStripMenuItem.Name = "thêmMớiToolStripMenuItem";
            thêmMớiToolStripMenuItem.ShortcutKeys = Keys.Control | Keys.N;
            thêmMớiToolStripMenuItem.ShowShortcutKeys = false;
            thêmMớiToolStripMenuItem.Size = new Size(224, 26);
            thêmMớiToolStripMenuItem.Text = "Thêm Mới";
            thêmMớiToolStripMenuItem.Click += thêmMớiToolStripMenuItem_Click;
            // 
            // thoátToolStripMenuItem
            // 
            thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            thoátToolStripMenuItem.Size = new Size(224, 26);
            thoátToolStripMenuItem.Text = "Thoát";
            thoátToolStripMenuItem.Click += thoátToolStripMenuItem_Click;
            // 
            // lsvSinhVien
            // 
            lsvSinhVien.Columns.AddRange(new ColumnHeader[] { columnSoTT, columnMSSV, columnTenSV, columnKhoa, columnDiemTB });
            lsvSinhVien.Dock = DockStyle.Fill;
            lsvSinhVien.FullRowSelect = true;
            lsvSinhVien.GridLines = true;
            lsvSinhVien.Location = new Point(0, 71);
            lsvSinhVien.Name = "lsvSinhVien";
            lsvSinhVien.Size = new Size(712, 379);
            lsvSinhVien.TabIndex = 3;
            lsvSinhVien.UseCompatibleStateImageBehavior = false;
            lsvSinhVien.View = View.Details;
            // 
            // columnSoTT
            // 
            columnSoTT.Text = "Số TT";
            columnSoTT.Width = 100;
            // 
            // columnMSSV
            // 
            columnMSSV.Text = "Mã Số SV";
            columnMSSV.Width = 100;
            // 
            // columnTenSV
            // 
            columnTenSV.Text = "Tên Sinh Viên";
            columnTenSV.Width = 150;
            // 
            // columnKhoa
            // 
            columnKhoa.Text = "Khoa";
            columnKhoa.Width = 200;
            // 
            // columnDiemTB
            // 
            columnDiemTB.Text = "Điểm TB";
            columnDiemTB.Width = 100;
            // 
            // tsbThem
            // 
            tsbThem.AutoSize = false;
            tsbThem.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tsbThem.Image = (Image)resources.GetObject("tsbThem.Image");
            tsbThem.ImageTransparentColor = Color.Magenta;
            tsbThem.Name = "tsbThem";
            tsbThem.Size = new Size(150, 40);
            tsbThem.Text = "Thêm Mới";
            tsbThem.Click += tsbThem_Click;
            // 
            // tslblTimTheoTen
            // 
            tslblTimTheoTen.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tslblTimTheoTen.Name = "tslblTimTheoTen";
            tslblTimTheoTen.Size = new Size(205, 40);
            tslblTimTheoTen.Text = "      Tìm Kiếm Theo Tên";
            // 
            // tsbTimKiem
            // 
            tsbTimKiem.AutoSize = false;
            tsbTimKiem.Name = "tsbTimKiem";
            tsbTimKiem.Size = new Size(300, 43);
            tsbTimKiem.TextChanged += tsbTimKiem_TextChanged;
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new Size(20, 20);
            toolStrip1.Items.AddRange(new ToolStripItem[] { tsbThem, tslblTimTheoTen, tsbTimKiem });
            toolStrip1.Location = new Point(0, 28);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(712, 43);
            toolStrip1.TabIndex = 2;
            toolStrip1.Text = "toolStrip1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(712, 450);
            Controls.Add(lsvSinhVien);
            Controls.Add(toolStrip1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Quản Lý Sinh Viên";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem chứcNăngToolStripMenuItem;
        private ToolStripMenuItem thêmMớiToolStripMenuItem;
        private ToolStripMenuItem thoátToolStripMenuItem;
        private ListView lsvSinhVien;
        private ColumnHeader columnSoTT;
        private ColumnHeader columnMSSV;
        private ColumnHeader columnTenSV;
        private ColumnHeader columnKhoa;
        private ColumnHeader columnDiemTB;
        private ToolStripButton tsbThem;
        private ToolStripLabel tslblTimTheoTen;
        private ToolStripTextBox tsbTimKiem;
        private ToolStrip toolStrip1;
    }
}
