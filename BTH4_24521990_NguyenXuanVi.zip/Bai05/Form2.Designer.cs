﻿namespace Bai05
{
    partial class FrmThemSV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblMSSV = new Label();
            lblTenSV = new Label();
            lblKhoa = new Label();
            lbldiemTB = new Label();
            txtMSSV = new TextBox();
            txtdiemTB = new TextBox();
            txtTenSV = new TextBox();
            cmbKhoa = new ComboBox();
            btnThemMoi = new Button();
            btnThoat = new Button();
            SuspendLayout();
            // 
            // lblMSSV
            // 
            lblMSSV.AutoSize = true;
            lblMSSV.Location = new Point(79, 48);
            lblMSSV.Name = "lblMSSV";
            lblMSSV.Size = new Size(116, 20);
            lblMSSV.TabIndex = 0;
            lblMSSV.Text = "Mã Số Sinh Viên";
            // 
            // lblTenSV
            // 
            lblTenSV.AutoSize = true;
            lblTenSV.Location = new Point(79, 117);
            lblTenSV.Name = "lblTenSV";
            lblTenSV.Size = new Size(97, 20);
            lblTenSV.TabIndex = 1;
            lblTenSV.Text = "Tên Sinh Viên";
            // 
            // lblKhoa
            // 
            lblKhoa.AutoSize = true;
            lblKhoa.Location = new Point(79, 186);
            lblKhoa.Name = "lblKhoa";
            lblKhoa.Size = new Size(43, 20);
            lblKhoa.TabIndex = 2;
            lblKhoa.Text = "Khoa";
            // 
            // lbldiemTB
            // 
            lbldiemTB.AutoSize = true;
            lbldiemTB.Location = new Point(79, 255);
            lbldiemTB.Name = "lbldiemTB";
            lbldiemTB.Size = new Size(66, 20);
            lbldiemTB.TabIndex = 3;
            lbldiemTB.Text = "Điểm TB";
            // 
            // txtMSSV
            // 
            txtMSSV.Location = new Point(215, 48);
            txtMSSV.Name = "txtMSSV";
            txtMSSV.Size = new Size(231, 27);
            txtMSSV.TabIndex = 4;
            txtMSSV.KeyPress += txtMSSV_KeyPress;
            // 
            // txtdiemTB
            // 
            txtdiemTB.Location = new Point(215, 248);
            txtdiemTB.Name = "txtdiemTB";
            txtdiemTB.Size = new Size(134, 27);
            txtdiemTB.TabIndex = 5;
            // 
            // txtTenSV
            // 
            txtTenSV.Location = new Point(215, 114);
            txtTenSV.Name = "txtTenSV";
            txtTenSV.Size = new Size(381, 27);
            txtTenSV.TabIndex = 6;
            // 
            // cmbKhoa
            // 
            cmbKhoa.FormattingEnabled = true;
            cmbKhoa.Items.AddRange(new object[] { "Công nghệ thông tin", "Công nghệ phần mềm", "Kỹ thuật máy tính", "Hệ thống thông tin", "Khoa học và Kỹ thuật thông tin", "Mạng máy tính và truyền thông" });
            cmbKhoa.Location = new Point(215, 186);
            cmbKhoa.Name = "cmbKhoa";
            cmbKhoa.Size = new Size(381, 28);
            cmbKhoa.TabIndex = 7;
            // 
            // btnThemMoi
            // 
            btnThemMoi.BackColor = Color.LimeGreen;
            btnThemMoi.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnThemMoi.Location = new Point(352, 353);
            btnThemMoi.Name = "btnThemMoi";
            btnThemMoi.Size = new Size(137, 49);
            btnThemMoi.TabIndex = 8;
            btnThemMoi.Text = "THÊM MỚI";
            btnThemMoi.UseVisualStyleBackColor = false;
            btnThemMoi.Click += btnThemMoi_Click;
            // 
            // btnThoat
            // 
            btnThoat.BackColor = Color.FromArgb(255, 128, 0);
            btnThoat.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnThoat.Location = new Point(514, 353);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(104, 49);
            btnThoat.TabIndex = 9;
            btnThoat.Text = "THOÁT";
            btnThoat.UseVisualStyleBackColor = false;
            btnThoat.Click += btnThoat_Click;
            // 
            // FrmThemSV
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnThoat);
            Controls.Add(btnThemMoi);
            Controls.Add(cmbKhoa);
            Controls.Add(txtTenSV);
            Controls.Add(txtdiemTB);
            Controls.Add(txtMSSV);
            Controls.Add(lbldiemTB);
            Controls.Add(lblKhoa);
            Controls.Add(lblTenSV);
            Controls.Add(lblMSSV);
            Name = "FrmThemSV";
            Text = "Thêm Sinh Viên";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblMSSV;
        private Label lblTenSV;
        private Label lblKhoa;
        private Label lbldiemTB;
        private TextBox txtMSSV;
        private TextBox txtdiemTB;
        private TextBox txtTenSV;
        private ComboBox cmbKhoa;
        private Button btnThemMoi;
        private Button btnThoat;
    }
}