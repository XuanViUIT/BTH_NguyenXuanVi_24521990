﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Linq;

namespace Bai05
{
    public partial class Form1 : Form
    {
        private List<Student> DSSinhVien = new List<Student>();

        public Form1()
        {
            InitializeComponent();
        }

        private void ThemSinhVien()
        {
            FrmThemSV formNhap = new FrmThemSV();
            if (formNhap.ShowDialog() == DialogResult.OK)
            {
                Student sv = formNhap.HocSinhMoi;
                DSSinhVien.Add(sv);
                HienThiLenListView(DSSinhVien);
            }
        }

        private void thêmMớiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ThemSinhVien();
        }

        private void tsbThem_Click(object sender, EventArgs e)
        {
            ThemSinhVien();
        }

        private void tsbTimKiem_TextChanged(object sender, EventArgs e)
        {
            string tukhoa = tsbTimKiem.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(tukhoa))
            {
                HienThiLenListView(DSSinhVien);
            }
            else
            {
                List<Student> KetQuaTimKiem = DSSinhVien
                    .Where(sv =>
                    {
                        string hoTenDayDu = sv.TenSV.Trim();
                        string[] cacTu = hoTenDayDu.Split(' ');
                        string tenRieng = cacTu.Last();

                        return tenRieng.ToLower().StartsWith(tukhoa);
                    })
                    .ToList();

                HienThiLenListView(KetQuaTimKiem);
            }
        }

        private void HienThiLenListView(List<Student> list)
        {
            lsvSinhVien.Items.Clear();

            for (int i = 0; i < list.Count; i++)
            {
                Student sv = list[i];

                ListViewItem item = new ListViewItem((i + 1).ToString());
                item.SubItems.Add(sv.MSSV);
                item.SubItems.Add(sv.TenSV);
                item.SubItems.Add(sv.Khoa);
                item.SubItems.Add(sv.diemTB.ToString());

                lsvSinhVien.Items.Add(item);
            }
        }

        private void thoátToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}