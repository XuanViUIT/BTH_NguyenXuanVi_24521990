﻿namespace Bai06
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            txtDich = new TextBox();
            txtNguon = new TextBox();
            btnChonNguon = new Button();
            btnChonDich = new Button();
            btnSaoChep = new Button();
            lblStatus = new Label();
            progressBar1 = new ProgressBar();
            toolTip1 = new ToolTip(components);
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(69, 77);
            label1.Name = "label1";
            label1.Size = new Size(209, 23);
            label1.TabIndex = 0;
            label1.Text = "Đường Dẫn Thư Mục Đích";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(69, 134);
            label2.Name = "label2";
            label2.Size = new Size(209, 23);
            label2.TabIndex = 1;
            label2.Text = "Đường Dẫn Thư Mục Đích";
            // 
            // txtDich
            // 
            txtDich.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtDich.Location = new Point(294, 130);
            txtDich.Name = "txtDich";
            txtDich.Size = new Size(390, 27);
            txtDich.TabIndex = 2;
            // 
            // txtNguon
            // 
            txtNguon.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtNguon.Location = new Point(294, 76);
            txtNguon.Name = "txtNguon";
            txtNguon.Size = new Size(390, 27);
            txtNguon.TabIndex = 3;
            // 
            // btnChonNguon
            // 
            btnChonNguon.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnChonNguon.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnChonNguon.ForeColor = SystemColors.HotTrack;
            btnChonNguon.Location = new Point(703, 73);
            btnChonNguon.Name = "btnChonNguon";
            btnChonNguon.Size = new Size(61, 29);
            btnChonNguon.TabIndex = 4;
            btnChonNguon.Text = "...";
            btnChonNguon.UseVisualStyleBackColor = true;
            // 
            // btnChonDich
            // 
            btnChonDich.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnChonDich.Font = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnChonDich.ForeColor = SystemColors.HotTrack;
            btnChonDich.Location = new Point(703, 130);
            btnChonDich.Name = "btnChonDich";
            btnChonDich.Size = new Size(61, 29);
            btnChonDich.TabIndex = 5;
            btnChonDich.Text = "...";
            btnChonDich.UseVisualStyleBackColor = true;
            // 
            // btnSaoChep
            // 
            btnSaoChep.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            btnSaoChep.BackColor = SystemColors.ControlLight;
            btnSaoChep.FlatStyle = FlatStyle.System;
            btnSaoChep.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSaoChep.Location = new Point(294, 194);
            btnSaoChep.Name = "btnSaoChep";
            btnSaoChep.Size = new Size(233, 46);
            btnSaoChep.TabIndex = 6;
            btnSaoChep.Text = "Sao Chép";
            btnSaoChep.UseVisualStyleBackColor = false;
            // 
            // lblStatus
            // 
            lblStatus.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lblStatus.AutoSize = true;
            lblStatus.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblStatus.Location = new Point(1, 418);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(138, 23);
            lblStatus.TabIndex = 7;
            lblStatus.Text = "Đang Sao Chép: ";
            // 
            // progressBar1
            // 
            progressBar1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            progressBar1.Location = new Point(69, 331);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(695, 35);
            progressBar1.TabIndex = 8;
            // 
            // backgroundWorker1
            // 
            backgroundWorker1.WorkerReportsProgress = true;
            backgroundWorker1.WorkerSupportsCancellation = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(progressBar1);
            Controls.Add(lblStatus);
            Controls.Add(btnSaoChep);
            Controls.Add(btnChonDich);
            Controls.Add(btnChonNguon);
            Controls.Add(txtNguon);
            Controls.Add(txtDich);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Sao chép tập tin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtDich;
        private TextBox txtNguon;
        private Button btnChonNguon;
        private Button btnChonDich;
        private Button btnSaoChep;
        private Label lblStatus;
        private ProgressBar progressBar1;
        private ToolTip toolTip1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}
