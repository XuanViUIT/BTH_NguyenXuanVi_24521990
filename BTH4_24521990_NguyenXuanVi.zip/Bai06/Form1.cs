﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;

namespace Bai06
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            toolTip1.SetToolTip(btnChonNguon, "Chọn thư mục chứa file cần copy");
            toolTip1.SetToolTip(btnChonDich, "Chọn thư mục sẽ lưu file");
            toolTip1.SetToolTip(btnSaoChep, "Bắt đầu quá trình sao chép");

            backgroundWorker1.DoWork += BackgroundWorker1_DoWork;
            backgroundWorker1.ProgressChanged += BackgroundWorker1_ProgressChanged;
            backgroundWorker1.RunWorkerCompleted += BackgroundWorker1_RunWorkerCompleted;
            btnChonNguon.Click += BtnChonNguon_Click;
            btnChonDich.Click += BtnChonDich_Click;
            btnSaoChep.Click += BtnSaoChep_Click;
        }

        private void BtnChonNguon_Click(object? sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                txtNguon.Text = fbd.SelectedPath;
            }
        }

        private void BtnChonDich_Click(object? sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                txtDich.Text = fbd.SelectedPath;
            }
        }
        private void BtnSaoChep_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNguon.Text) || string.IsNullOrEmpty(txtDich.Text))
            {
                MessageBox.Show("Vui lòng chọn đầy đủ đường dẫn nguồn và đích!");
                return;
            }

            if (!Directory.Exists(txtNguon.Text))
            {
                MessageBox.Show("Thư mục nguồn không tồn tại!");
                return;
            }

            btnSaoChep.Enabled = false;

            backgroundWorker1.RunWorkerAsync();
        }

        private void BackgroundWorker1_DoWork(object? sender, DoWorkEventArgs e)
        {
            string sourceDir = txtNguon.Text;
            string destDir = txtDich.Text;

            if (!Directory.Exists(destDir))
            {
                Directory.CreateDirectory(destDir);
            }

            string[] files = Directory.GetFiles(sourceDir);
            int totalFiles = files.Length;

            for (int i = 0; i < totalFiles; i++)
            {
                string sourceFile = files[i];
                string fileName = Path.GetFileName(sourceFile);
                string destFile = Path.Combine(destDir, fileName);
                File.Copy(sourceFile, destFile, true);

                System.Threading.Thread.Sleep(100);

                int percentComplete = (int)((float)(i + 1) / totalFiles * 100);

                backgroundWorker1.ReportProgress(percentComplete, fileName);
            }
        }

        private void BackgroundWorker1_ProgressChanged(object? sender, ProgressChangedEventArgs e)
        {
            progressBar1.Value = e.ProgressPercentage;

            lblStatus.Text = "Đang sao chép: " + e.UserState?.ToString();
        }

        private void BackgroundWorker1_RunWorkerCompleted(object? sender, RunWorkerCompletedEventArgs e)
        {
            btnSaoChep.Enabled = true;
            MessageBox.Show("Sao chép thành công!");
        }
    }
}