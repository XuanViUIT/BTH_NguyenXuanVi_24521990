﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai04
{
    public partial class Form1 : Form
    {
        private string currentFilePath = "";
        public Form1()
        {
            InitializeComponent();
        }
        private void ThayDoiKieuChu(FontStyle styleCanThayDoi)
        {
            RichTextBox rtb = richTextBox1;
            rtb.SuspendLayout();

            int start = rtb.SelectionStart;
            int len = rtb.SelectionLength;

            if (len == 0)
            {
                Font currentFont = rtb.SelectionFont;
                FontStyle newStyle = currentFont.Style ^ styleCanThayDoi;
                rtb.SelectionFont = new Font(currentFont.FontFamily, currentFont.Size, newStyle);
            }
            else
            {
                for (int i = 0; i < len; i++)
                {
                    rtb.Select(start + i, 1);
                    Font currentCharFont = rtb.SelectionFont;
                    FontStyle newStyle = currentCharFont.Style ^ styleCanThayDoi;
                    rtb.SelectionFont = new Font(currentCharFont.FontFamily, currentCharFont.Size, newStyle);
                }
                rtb.Select(start, len);
            }
            rtb.ResumeLayout();
        }
        private void TaoVanBanMoiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            currentFilePath = "";
            cmbFont.Text = "Tahoma";
            cmbSize.Text = "14";
            richTextBox1.Font = new Font("Tahoma", 14, FontStyle.Regular);
        }

        private void LuuToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog saveDlg = new SaveFileDialog();
            saveDlg.Filter = "Rich Text Format (*.rtf)|*.rtf|Text Files (*.txt)|*.txt";

            if (saveDlg.ShowDialog() == DialogResult.OK)
            {
                if (saveDlg.FileName.ToLower().EndsWith(".rtf"))
                {
                    richTextBox1.SaveFile(saveDlg.FileName, RichTextBoxStreamType.RichText);
                }
                else
                {
                    richTextBox1.SaveFile(saveDlg.FileName, RichTextBoxStreamType.PlainText);
                }
            }
        }

        private void MoTapTinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDlg = new OpenFileDialog();
            openDlg.Filter = "Rich Text Format (*.rtf)|*.rtf|Text Files (*.txt)|*.txt";

            if (openDlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string path = openDlg.FileName;

                    if (path.ToLower().EndsWith(".rtf"))
                    {
                        richTextBox1.LoadFile(path, RichTextBoxStreamType.RichText);
                    }
                    else
                    {
                        richTextBox1.LoadFile(path, RichTextBoxStreamType.PlainText);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi mở file: " + ex.Message);
                }
            }
        }

        private void ThoatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void DinhDangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(richTextBox1.SelectionFont != null)
            {
                fontDialog1.Font = richTextBox1.SelectionFont;
            }
            
            fontDialog1.Color = richTextBox1.SelectionColor;

            if(fontDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionFont = fontDialog1.Font;
                richTextBox1.SelectionColor = fontDialog1.Color;
            }
        }

        private void BoldtoolStripButton_Click(object sender, EventArgs e)
        {
            ThayDoiKieuChu(FontStyle.Bold);
        }

        private void ItalictoolStripButton_Click(object sender, EventArgs e)
        {
            ThayDoiKieuChu(FontStyle.Italic);
        }

        private void UnderlinetoolStripButton_Click(object sender, EventArgs e)
        {
            ThayDoiKieuChu(FontStyle.Underline);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach(FontFamily font in FontFamily.Families)
            {
                cmbFont.Items.Add(font.Name);
            }

            int[] sizes = { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72 };
            foreach(int s in sizes)
            {
                cmbSize.Items.Add(s);
            }

            cmbFont.Text = "Tahoma";
            cmbSize.Text = "14";
            richTextBox1.Font = new Font("Tahoma", 14);
        }

        private void BlanktoolStripButton_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            currentFilePath = "";
            cmbFont.Text = "Tahoma";
            cmbSize.Text = "14";
            richTextBox1.Font = new Font("Tahoma", 14);
        }

        private void SavetoolStripButton_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(currentFilePath))
            {
                SaveFileDialog saveDlg = new SaveFileDialog();
                saveDlg.Filter = "Rich Text Format (*.rtf)|*.rtf";

                if(saveDlg.ShowDialog() == DialogResult.OK)
                {
                    currentFilePath = saveDlg.FileName;
                    richTextBox1.SaveFile(currentFilePath);
                    MessageBox.Show("Lưu văn bản mới thành công");
                }
            }
            else
            {
                richTextBox1.SaveFile(currentFilePath);
                MessageBox.Show("Lưu văn bản thành công");
            }
        }

        private void cmbFont_SelectedIndexChanged(object sender, EventArgs e)
        {

            string newFontName = cmbFont.SelectedItem.ToString();
            Font CurrentFont = richTextBox1.SelectionFont ?? richTextBox1.Font;
            richTextBox1.SelectionFont = new Font(newFontName, CurrentFont.Size, CurrentFont.Style);
        }

        private void cmbSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            float newSizeName = float.Parse(cmbSize.SelectedItem.ToString());
            Font CurrentFont = richTextBox1.SelectionFont ?? richTextBox1.Font;
            richTextBox1.SelectionFont = new Font(CurrentFont.FontFamily, newSizeName, CurrentFont.Style);
        }
    }
}
