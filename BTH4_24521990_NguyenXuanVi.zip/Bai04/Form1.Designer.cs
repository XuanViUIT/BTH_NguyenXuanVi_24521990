﻿namespace Bai04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.HeThongToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TaoVanBanMoiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MoTapTinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LuuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ThoatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DinhDangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.BlanktoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.SavetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.cmbFont = new System.Windows.Forms.ToolStripComboBox();
            this.cmbSize = new System.Windows.Forms.ToolStripComboBox();
            this.BoldtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.ItalictoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.UnderlinetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.HeThongToolStripMenuItem,
            this.DinhDangToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // HeThongToolStripMenuItem
            // 
            this.HeThongToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TaoVanBanMoiToolStripMenuItem,
            this.MoTapTinToolStripMenuItem,
            this.LuuToolStripMenuItem,
            this.ThoatToolStripMenuItem});
            this.HeThongToolStripMenuItem.Name = "HeThongToolStripMenuItem";
            this.HeThongToolStripMenuItem.Size = new System.Drawing.Size(85, 26);
            this.HeThongToolStripMenuItem.Text = "Hệ thống";
            // 
            // TaoVanBanMoiToolStripMenuItem
            // 
            this.TaoVanBanMoiToolStripMenuItem.Name = "TaoVanBanMoiToolStripMenuItem";
            this.TaoVanBanMoiToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.TaoVanBanMoiToolStripMenuItem.Size = new System.Drawing.Size(285, 26);
            this.TaoVanBanMoiToolStripMenuItem.Text = "Tạo văn bản mới";
            this.TaoVanBanMoiToolStripMenuItem.Click += new System.EventHandler(this.TaoVanBanMoiToolStripMenuItem_Click);
            // 
            // MoTapTinToolStripMenuItem
            // 
            this.MoTapTinToolStripMenuItem.Name = "MoTapTinToolStripMenuItem";
            this.MoTapTinToolStripMenuItem.Size = new System.Drawing.Size(285, 26);
            this.MoTapTinToolStripMenuItem.Text = "Mở tập tin";
            this.MoTapTinToolStripMenuItem.Click += new System.EventHandler(this.MoTapTinToolStripMenuItem_Click);
            // 
            // LuuToolStripMenuItem
            // 
            this.LuuToolStripMenuItem.Name = "LuuToolStripMenuItem";
            this.LuuToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.LuuToolStripMenuItem.Size = new System.Drawing.Size(285, 26);
            this.LuuToolStripMenuItem.Text = "Lưu nội dung văn bản";
            this.LuuToolStripMenuItem.Click += new System.EventHandler(this.LuuToolStripMenuItem_Click_1);
            // 
            // ThoatToolStripMenuItem
            // 
            this.ThoatToolStripMenuItem.Name = "ThoatToolStripMenuItem";
            this.ThoatToolStripMenuItem.Size = new System.Drawing.Size(285, 26);
            this.ThoatToolStripMenuItem.Text = "Thoát";
            this.ThoatToolStripMenuItem.Click += new System.EventHandler(this.ThoatToolStripMenuItem_Click);
            // 
            // DinhDangToolStripMenuItem
            // 
            this.DinhDangToolStripMenuItem.Name = "DinhDangToolStripMenuItem";
            this.DinhDangToolStripMenuItem.Size = new System.Drawing.Size(92, 26);
            this.DinhDangToolStripMenuItem.Text = "Định dạng";
            this.DinhDangToolStripMenuItem.Click += new System.EventHandler(this.DinhDangToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BlanktoolStripButton,
            this.SavetoolStripButton,
            this.cmbFont,
            this.cmbSize,
            this.BoldtoolStripButton,
            this.ItalictoolStripButton,
            this.UnderlinetoolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 28);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // BlanktoolStripButton
            // 
            this.BlanktoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BlanktoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("BlanktoolStripButton.Image")));
            this.BlanktoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BlanktoolStripButton.Name = "BlanktoolStripButton";
            this.BlanktoolStripButton.Size = new System.Drawing.Size(29, 25);
            this.BlanktoolStripButton.Text = "Văn bản mới";
            this.BlanktoolStripButton.Click += new System.EventHandler(this.BlanktoolStripButton_Click);
            // 
            // SavetoolStripButton
            // 
            this.SavetoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.SavetoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("SavetoolStripButton.Image")));
            this.SavetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SavetoolStripButton.Name = "SavetoolStripButton";
            this.SavetoolStripButton.Size = new System.Drawing.Size(29, 28);
            this.SavetoolStripButton.Text = "Lưu";
            this.SavetoolStripButton.Click += new System.EventHandler(this.SavetoolStripButton_Click);
            // 
            // cmbFont
            // 
            this.cmbFont.Name = "cmbFont";
            this.cmbFont.Size = new System.Drawing.Size(121, 31);
            this.cmbFont.SelectedIndexChanged += new System.EventHandler(this.cmbFont_SelectedIndexChanged);
            // 
            // cmbSize
            // 
            this.cmbSize.Name = "cmbSize";
            this.cmbSize.Size = new System.Drawing.Size(121, 31);
            this.cmbSize.SelectedIndexChanged += new System.EventHandler(this.cmbSize_SelectedIndexChanged);
            // 
            // BoldtoolStripButton
            // 
            this.BoldtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BoldtoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("BoldtoolStripButton.Image")));
            this.BoldtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BoldtoolStripButton.Name = "BoldtoolStripButton";
            this.BoldtoolStripButton.Size = new System.Drawing.Size(29, 28);
            this.BoldtoolStripButton.Text = "In đậm";
            this.BoldtoolStripButton.Click += new System.EventHandler(this.BoldtoolStripButton_Click);
            // 
            // ItalictoolStripButton
            // 
            this.ItalictoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.ItalictoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("ItalictoolStripButton.Image")));
            this.ItalictoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ItalictoolStripButton.Name = "ItalictoolStripButton";
            this.ItalictoolStripButton.Size = new System.Drawing.Size(29, 28);
            this.ItalictoolStripButton.Text = "In nghiêng";
            this.ItalictoolStripButton.Click += new System.EventHandler(this.ItalictoolStripButton_Click);
            // 
            // UnderlinetoolStripButton
            // 
            this.UnderlinetoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.UnderlinetoolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("UnderlinetoolStripButton.Image")));
            this.UnderlinetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.UnderlinetoolStripButton.Name = "UnderlinetoolStripButton";
            this.UnderlinetoolStripButton.Size = new System.Drawing.Size(29, 28);
            this.UnderlinetoolStripButton.Text = "Gạch chân";
            this.UnderlinetoolStripButton.Click += new System.EventHandler(this.UnderlinetoolStripButton_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.White;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.Location = new System.Drawing.Point(0, 56);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(800, 394);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // fontDialog1
            // 
            this.fontDialog1.ShowColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Soạn thảo văn bản";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem HeThongToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DinhDangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TaoVanBanMoiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MoTapTinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem LuuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ThoatToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton BlanktoolStripButton;
        private System.Windows.Forms.ToolStripButton SavetoolStripButton;
        private System.Windows.Forms.ToolStripComboBox cmbFont;
        private System.Windows.Forms.ToolStripComboBox cmbSize;
        private System.Windows.Forms.ToolStripButton BoldtoolStripButton;
        private System.Windows.Forms.ToolStripButton ItalictoolStripButton;
        private System.Windows.Forms.ToolStripButton UnderlinetoolStripButton;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.FontDialog fontDialog1;
    }
}

